install.packages('devtools', repos = 'http://cran.us.r-project.org')
devtools::install_github('liulch/bpCausal')

## Iran

library(bpCausal)
library(dplyr)
library(ggplot2)

# ????????
data <- read.csv('panel data.csv')
# ?ϲ?ɸѡ????
data_filtered <- data %>%
  filter(Iccd %in% c(20,100,101,130,385,630,481,645,670,690,692,694,698,775,820,850,900) &
           Iyea >= 1960 & Iyea <= 1991)
data <- data_filtered %>%
  mutate(D = ifelse(Iccd == 630 & Iyea >= 1975, 1, 0))

# bpCausal
out1 <- bpCausal(
  data = data,
  index = c("Iccd", "Iyea"),
  Yname = "Aegr3", 
  Dname = "D", 
  Xname = c("Bopd1", "Bgpd1", "Crty1", "Cwar1", "Cncp1", "Cppl1", "Crlg2", "Ceth1", "Crus2"), 
  Zname = NULL, 
  Aname = NULL,
  re = "none", 
  ar1 = FALSE, 
  r = 10,
  placebo_period = 0,
  niter = 50000,
  burn = 5000,
  xlasso = 1, 
  zlasso = 0, 
  alasso = 0, 
  flasso = 1, 
  a1 = 0.001, a2 = 0.001, 
  b1 = 0.001, b2 = 0.001, 
  c1 = 0.001, c2 = 0.001, 
  p1 = 0.001, p2 = 0.001 
)

# ?ܽ??��Ʋ???
sout_fixed <- coefSummary(out1)

# ?ܽᴦ??ЧӦ
eout_fixed <- effSummary(out1, usr.id = NULL, cumu = FALSE, rela.period = TRUE)

print(sout_fixed)
print(eout_fixed)

# ------------------------------
# Counterfactual
# ------------------------------

library(ggplot2)
actual_outcomes <- eout_fixed$est.eff %>%
  select(time, observed) %>%
  rename(Iyea = time, actual = observed)

counterfactual_outcomes <- eout_fixed$est.eff %>%
  select(time, estimated_counterfactual) %>%
  rename(Iyea = time, counterfactual = estimated_counterfactual)

plot_data <- merge(actual_outcomes, counterfactual_outcomes, by = "Iyea")

p <- ggplot(plot_data, aes(x = Iyea)) +
  geom_line(aes(y = actual, color = "Actual"), linetype = "solid", color = "black") +
  geom_line(aes(y = counterfactual, color = "Counterfactual"), linetype = "dashed", color = "black") +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey") +
  scale_x_continuous(breaks = seq(-14, 17, by = 5), labels = seq(1960, 1991, by = 5)) +
  labs(x = "????",
       y = "?????????ٶ?",
       color = "Legend") +
  theme_minimal(base_size = 15) +
  theme(plot.title = element_text(size = 14, face = "bold"),
        axis.title = element_text(size = 12),
        axis.text.x = element_text(size = 10, hjust = 1), 
        axis.text.y = element_text(size = 10),
        legend.title = element_text(size = 12),
        legend.text = element_text(size = 10),
        panel.background = element_rect(fill = "white", color = "white"),
        plot.background = element_rect(fill = "white", color = "white"),
        legend.background = element_rect(fill = "white", color = "white"),
        legend.key = element_rect(fill = "white", color = "white"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(color = "black"))

print(p)
ggsave("Iran_Fixed_Counterfactual.png", plot = p, width = 10, height = 7, dpi = 1200)

# ------------------------------
# ATT
# ------------------------------

x_fixed <- eout_fixed$est.eff$time
att_fixed <- eout_fixed$est.eff$estimated_ATT
ci_lower_fixed <- eout_fixed$est.eff$estimated_ATT_ci_l
ci_upper_fixed <- eout_fixed$est.eff$estimated_ATT_ci_u

plot_data <- data.frame(
  Time = x_fixed,
  ATT = att_fixed,
  CI_Lower = ci_lower_fixed,
  CI_Upper = ci_upper_fixed
)

p <- ggplot(plot_data, aes(x = Time, y = ATT)) +
  geom_line(color = "black", size = 1) +
  geom_ribbon(aes(ymin = CI_Lower, ymax = CI_Upper), fill = "grey", alpha = 0.3) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "grey") +
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey") + 
  scale_x_continuous(breaks = seq(-14, 17, by = 5), labels = seq(1960, 1991, by = 5)) +
  scale_y_continuous(limits = c(min(ci_lower_fixed) - 0.3, max(ci_upper_fixed) + 0.6)) + 
  labs(title = "ATT over Time with 95% Confidence Interval",
       x = "Time",
       y = "ATT") +
  theme_minimal(base_size = 15) +
  theme(plot.title = element_text(size = 14, face = "bold"),
        axis.title = element_text(size = 12),
        axis.text.x = element_text(size = 10, hjust = 1), 
        axis.text.y = element_text(size = 10),
        panel.background = element_rect(fill = "white", color = "white"),
        plot.background = element_rect(fill = "white", color = "white"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(color = "black"))
print(p)
ggsave("Iran_Fixed_ATT.png", plot = p, width = 10, height = 7, dpi = 1200)


# ------------------------------
# Placebo
# ------------------------------

data_placebo <- data_filtered %>%
  mutate(D_placebo = ifelse(Iccd == 475 & Iyea >= 1974, 1, 0)) # 将处理提前两???

out_placebo <- bpCausal(
  data = data_placebo, 
  index = c("Iccd", "Iyea"),
  Yname = "Aegr3",
  Dname = "D_placebo", 
  Xname = c("Bopd1", "Bgpd1", "Crty1", "Cwar1", "Cncp1", "Cppl1", "Crlg2", "Ceth1", "Crus2"),
  Zname = NULL, 
  Aname = NULL,
  re = "none", 
  ar1 = FALSE, 
  r = 10,
  placebo_period = 0,
  niter = 50000,
  burn = 5000,
  xlasso = 1, 
  zlasso = 0, 
  alasso = 0, 
  flasso = 1, 
  a1 = 0.001, a2 = 0.001, 
  b1 = 0.001, b2 = 0.001, 
  c1 = 0.001, c2 = 0.001, 
  p1 = 0.001, p2 = 0.001 
)

sout_placebo <- coefSummary(out_placebo)
eout_placebo <- effSummary(out_placebo, usr.id = NULL, cumu = FALSE, rela.period = TRUE)

x_fixed <- eout_placebo$est.eff$time
att_fixed <- eout_placebo$est.eff$estimated_ATT
ci_lower_fixed <- eout_placebo$est.eff$estimated_ATT_ci_l
ci_upper_fixed <- eout_placebo$est.eff$estimated_ATT_ci_u

plot_data <- data.frame(
  Time = x_fixed,
  ATT = att_fixed,
  CI_Lower = ci_lower_fixed,
  CI_Upper = ci_upper_fixed
)

p <- ggplot(plot_data, aes(x = Time, y = ATT)) +
  geom_line(color = "black", size = 1) +
  geom_ribbon(aes(ymin = CI_Lower, ymax = CI_Upper), fill = "grey", alpha = 0.3) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "grey") +
  geom_vline(xintercept = -2, linetype = "dashed", color = "grey") + 
  geom_vline(xintercept = 0, linetype = "dashed", color = "grey") + 
  scale_x_continuous(breaks = seq(-14, 17, by = 5), labels = seq(1960, 1991, by = 5)) +
  scale_y_continuous(limits = c(min(ci_lower_fixed) - 0.3, max(ci_upper_fixed) + 0.6)) + 
  labs(title = "ATT over Time with 95% Confidence Interval (placebo)",
       x = "Time",
       y = "ATT") +
  theme_minimal(base_size = 15) +
  theme(plot.title = element_text(size = 14, face = "bold"),
        axis.title = element_text(size = 12),
        axis.text.x = element_text(size = 10, hjust = 1), 
        axis.text.y = element_text(size = 10),
        panel.background = element_rect(fill = "white", color = "white"),
        plot.background = element_rect(fill = "white", color = "white"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(color = "black"))
print(p)
ggsave("Iran_Fixed_ATT_Placebo.png", plot = p, width = 10, height = 7, dpi = 1200)

install.packages('devtools', repos = 'http://cran.us.r-project.org')
devtools::install_github('liulch/bpCausal')


## Nigeria
library(bpCausal)
library(dplyr)
library(ggplot2)

# ????????
data <- read.csv('panel data.csv')
# ?ϲ?ɸѡ????
data_filtered <- data %>%
  filter(Iccd %in% c(20,100,101,130,385,475,481,645,670,690,692,694,698,775,820,850,900) &
           Iyea >= 1960 & Iyea <= 1991)
data <- data_filtered %>%
  mutate(D = ifelse(Iccd == 475 & Iyea >= 1975, 1, 0))

# bpCausal
out1 <- bpCausal(
  data = data,
  index = c("Iccd", "Iyea"),
  Yname = "Aegr3", 
  Dname = "D", 
  Xname = c("Bopd1", "Bgpd1", "Crty1", "Cwar1", "Cncp1", "Cppl1", "Crlg2", "Ceth1", "Crus2"), 
  Zname = NULL, 
  Aname = NULL,
  re = "none", 
  ar1 = FALSE, 
  r = 10,
  placebo_period = 0,
  niter = 50000,
  burn = 5000,
  xlasso = 1, 
  zlasso = 0, 
  alasso = 0, 
  flasso = 1, 
  a1 = 0.001, a2 = 0.001, 
  b1 = 0.001, b2 = 0.001, 
  c1 = 0.001, c2 = 0.001, 
  p1 = 0.001, p2 = 0.001 
)

# ?ܽ??��Ʋ???
sout_fixed <- coefSummary(out1)

# ?ܽᴦ??ЧӦ
eout_fixed <- effSummary(out1, usr.id = NULL, cumu = FALSE, rela.period = TRUE)

print(sout_fixed)
print(eout_fixed)

# ------------------------------
# Counterfactual
# ------------------------------

library(ggplot2)
actual_outcomes <- eout_fixed$est.eff %>%
  select(time, observed) %>%
  rename(Iyea = time, actual = observed)

counterfactual_outcomes <- eout_fixed$est.eff %>%
  select(time, estimated_counterfactual) %>%
  rename(Iyea = time, counterfactual = estimated_counterfactual)

plot_data <- merge(actual_outcomes, counterfactual_outcomes, by = "Iyea")

p <- ggplot(plot_data, aes(x = Iyea)) +
  geom_line(aes(y = actual, color = "Actual"), linetype = "solid", color = "black") +
  geom_line(aes(y = counterfactual, color = "Counterfactual"), linetype = "dashed", color = "black") +
  geom_vline(xintercept = 1, linetype = "dashed", color = "grey") +
  scale_x_continuous(breaks = seq(-14, 17, by = 5), labels = seq(1960, 1991, by = 5)) +
  labs(x = "????",
       y = "?????????ٶ?",
       color = "Legend") +
  theme_minimal(base_size = 15) +
  theme(plot.title = element_text(size = 14, face = "bold"),
        axis.title = element_text(size = 12),
        axis.text.x = element_text(size = 10, hjust = 1), 
        axis.text.y = element_text(size = 10),
        legend.title = element_text(size = 12),
        legend.text = element_text(size = 10),
        panel.background = element_rect(fill = "white", color = "white"),
        plot.background = element_rect(fill = "white", color = "white"),
        legend.background = element_rect(fill = "white", color = "white"),
        legend.key = element_rect(fill = "white", color = "white"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(color = "black"))

print(p)
ggsave("Iran_Fixed_Counterfactual.png", plot = p, width = 10, height = 7, dpi = 1200)

# ------------------------------
# ATT
# ------------------------------

x_fixed <- eout_fixed$est.eff$time
att_fixed <- eout_fixed$est.eff$estimated_ATT
ci_lower_fixed <- eout_fixed$est.eff$estimated_ATT_ci_l
ci_upper_fixed <- eout_fixed$est.eff$estimated_ATT_ci_u

plot_data <- data.frame(
  Time = x_fixed,
  ATT = att_fixed,
  CI_Lower = ci_lower_fixed,
  CI_Upper = ci_upper_fixed
)

p <- ggplot(plot_data, aes(x = Time, y = ATT)) +
  geom_line(color = "black", size = 1) +
  geom_ribbon(aes(ymin = CI_Lower, ymax = CI_Upper), fill = "grey", alpha = 0.3) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "grey") +
  geom_vline(xintercept = 1, linetype = "dashed", color = "grey") + 
  scale_x_continuous(breaks = seq(-14, 17, by = 5), labels = seq(1960, 1991, by = 5)) +
  scale_y_continuous(limits = c(min(ci_lower_fixed) - 0.3, max(ci_upper_fixed) + 0.6)) + 
  labs(title = "ATT over Time with 95% Confidence Interval",
       x = "Time",
       y = "ATT") +
  theme_minimal(base_size = 15) +
  theme(plot.title = element_text(size = 14, face = "bold"),
        axis.title = element_text(size = 12),
        axis.text.x = element_text(size = 10, hjust = 1), 
        axis.text.y = element_text(size = 10),
        panel.background = element_rect(fill = "white", color = "white"),
        plot.background = element_rect(fill = "white", color = "white"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(color = "black"))
print(p)
ggsave("Iran_Fixed_ATT.png", plot = p, width = 10, height = 7, dpi = 1200)


# ------------------------------
# Placebo
# ------------------------------

data_placebo <- data_filtered %>%
  mutate(D_placebo = ifelse(Iccd == 475 & Iyea >= 1974, 1, 0)) # 将处理提前两???

out_placebo <- bpCausal(
  data = data_placebo, 
  index = c("Iccd", "Iyea"),
  Yname = "Aegr3",
  Dname = "D_placebo", 
  Xname = c("Bopd1", "Bgpd1", "Crty1", "Cwar1", "Cncp1", "Cppl1", "Crlg2", "Ceth1", "Crus2"),
  Zname = NULL, 
  Aname = NULL,
  re = "none", 
  ar1 = FALSE, 
  r = 10,
  placebo_period = 0,
  niter = 50000,
  burn = 5000,
  xlasso = 1, 
  zlasso = 0, 
  alasso = 0, 
  flasso = 1, 
  a1 = 0.001, a2 = 0.001, 
  b1 = 0.001, b2 = 0.001, 
  c1 = 0.001, c2 = 0.001, 
  p1 = 0.001, p2 = 0.001 
)

sout_placebo <- coefSummary(out_placebo)
eout_placebo <- effSummary(out_placebo, usr.id = NULL, cumu = FALSE, rela.period = TRUE)

x_fixed <- eout_placebo$est.eff$time
att_fixed <- eout_placebo$est.eff$estimated_ATT
ci_lower_fixed <- eout_placebo$est.eff$estimated_ATT_ci_l
ci_upper_fixed <- eout_placebo$est.eff$estimated_ATT_ci_u

plot_data <- data.frame(
  Time = x_fixed,
  ATT = att_fixed,
  CI_Lower = ci_lower_fixed,
  CI_Upper = ci_upper_fixed
)

p <- ggplot(plot_data, aes(x = Time, y = ATT)) +
  geom_line(color = "black", size = 1) +
  geom_ribbon(aes(ymin = CI_Lower, ymax = CI_Upper), fill = "grey", alpha = 0.3) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "grey") +
  geom_vline(xintercept = -1, linetype = "dashed", color = "grey") + 
  geom_vline(xintercept = 1, linetype = "dashed", color = "grey") + 
  scale_x_continuous(breaks = seq(-14, 17, by = 5), labels = seq(1960, 1991, by = 5)) +
  scale_y_continuous(limits = c(min(ci_lower_fixed) - 0.3, max(ci_upper_fixed) + 0.6)) + 
  labs(title = "ATT over Time with 95% Confidence Interval (placebo)",
       x = "Time",
       y = "ATT") +
  theme_minimal(base_size = 15) +
  theme(plot.title = element_text(size = 14, face = "bold"),
        axis.title = element_text(size = 12),
        axis.text.x = element_text(size = 10, hjust = 1), 
        axis.text.y = element_text(size = 10),
        panel.background = element_rect(fill = "white", color = "white"),
        plot.background = element_rect(fill = "white", color = "white"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.line = element_line(color = "black"))
print(p)
ggsave("Iran_Fixed_ATT_Placebo.png", plot = p, width = 10, height = 7, dpi = 1200)
